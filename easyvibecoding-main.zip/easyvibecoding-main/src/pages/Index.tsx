import { Button } from "@/components/ui/button";
import { FeatureCard } from "@/components/FeatureCard";
import { ProgressPillar } from "@/components/ProgressPillar";
import { DifferenceCard } from "@/components/DifferenceCard";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { 
  Code2, 
  Sparkles, 
  Rocket, 
  Trophy, 
  Users, 
  Brain, 
  Target, 
  Heart,
  Zap,
  Clock,
  MessageCircle,
  ArrowRight,
  Eye,
  TrendingUp,
  Smile
} from "lucide-react";
import heroImage from "@/assets/hero-coding.jpg";

const Index = () => {
  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-subtle">
        <div className="absolute inset-0 opacity-20">
          <img 
            src={heroImage} 
            alt="VibeCoding - La technologie qui se ressent" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background" />
        
        <div className="container mx-auto px-6 py-20 relative z-10">
          <div className="max-w-5xl mx-auto text-center space-y-8 animate-fade-in-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-hero text-primary-foreground text-sm font-medium shadow-glow mb-4">
              <Sparkles className="w-4 h-4" />
              <span>Nouvelle approche pédagogique</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold text-foreground leading-tight">
              VibeCoding
              <span className="block text-transparent bg-clip-text bg-gradient-vibrant mt-2">
                la technologie qui se ressent
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              Apprends la tech comme une expérience vivante. Moins de théorie plate, 
              plus de pratique guidée par l'envie et la vibe.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4">
              <Button 
                size="lg" 
                className="bg-gradient-hero text-primary-foreground hover:shadow-glow transition-all duration-300 text-lg px-8 py-6 group"
                onClick={() => scrollToSection("concept")}
              >
                Découvrir le concept
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="text-lg px-8 py-6 border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-all duration-300"
                onClick={() => scrollToSection("formation")}
              >
                Rejoindre la formation
              </Button>
            </div>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 rounded-full border-2 border-primary flex items-start justify-center p-2">
            <div className="w-1.5 h-3 bg-primary rounded-full animate-pulse" />
          </div>
        </div>
      </section>

      {/* Concept Section */}
      <section id="concept" className="py-24 bg-background">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center space-y-6 mb-16 animate-fade-in-up">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground">
              C'est quoi, VibeCoding ?
            </h2>
            <div className="w-24 h-1 bg-gradient-hero mx-auto rounded-full" />
            <p className="text-xl text-muted-foreground leading-relaxed">
              VibeCoding, c'est une façon d'apprendre la tech qui te donne envie de coder chaque jour.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <div className="col-span-full md:col-span-2 lg:col-span-1">
              <div className="h-full p-8 rounded-2xl bg-gradient-hero text-primary-foreground shadow-glow">
                <Zap className="w-12 h-12 mb-4 animate-pulse-glow" />
                <h3 className="text-2xl font-bold mb-4">Une expérience vivante</h3>
                <p className="text-lg opacity-95 leading-relaxed">
                  Apprendre la tech ne devrait pas être ennuyeux. On crée une atmosphère 
                  où chaque ligne de code est une découverte motivante.
                </p>
              </div>
            </div>

            <div className="p-8 rounded-2xl bg-card border border-border/50 shadow-card hover:shadow-soft transition-all duration-300 hover:-translate-y-1">
              <Brain className="w-10 h-10 mb-4 text-secondary" />
              <h3 className="text-xl font-bold mb-3 text-foreground">Moins de théorie</h3>
              <p className="text-muted-foreground leading-relaxed">
                On passe directement à la pratique. Tu apprends en créant, 
                pas en mémorisant des concepts abstraits.
              </p>
            </div>

            <div className="p-8 rounded-2xl bg-card border border-border/50 shadow-card hover:shadow-soft transition-all duration-300 hover:-translate-y-1">
              <Heart className="w-10 h-10 mb-4 text-accent" />
              <h3 className="text-xl font-bold mb-3 text-foreground">Guidé par l'envie</h3>
              <p className="text-muted-foreground leading-relaxed">
                Chaque projet est choisi pour maintenir ta motivation. 
                Tu codes ce qui te passionne.
              </p>
            </div>

            <div className="col-span-full p-8 rounded-2xl bg-gradient-subtle border border-border/30 shadow-card">
              <div className="flex items-center gap-4 mb-4">
                <TrendingUp className="w-10 h-10 text-primary" />
                <h3 className="text-xl font-bold text-foreground">Progression naturelle</h3>
              </div>
              <p className="text-muted-foreground text-lg leading-relaxed">
                Sensation de rythme, d'évolution constante. Chaque semaine, tu vois tes compétences grandir 
                de manière tangible et mesurable.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Training Content Section */}
      <section id="formation" className="py-24 bg-gradient-section">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center space-y-6 mb-16 animate-fade-in-up">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground">
              Ce qu'on fait dans la formation
            </h2>
            <div className="w-24 h-1 bg-gradient-hero mx-auto rounded-full" />
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            <FeatureCard
              icon={Code2}
              title="Création de vrais projets"
              description="Web apps, jeux simples, automations... Tu construis des projets concrets qui enrichissent ton portfolio."
              delay={0}
            />
            <FeatureCard
              icon={Trophy}
              title="Défis quotidiens"
              description="Des challenges adaptés à ton niveau pour progresser sans pression, à ton rythme."
              delay={100}
            />
            <FeatureCard
              icon={Rocket}
              title="Ateliers pratiques"
              description="Sessions hands-on où tu appliques immédiatement ce que tu apprends."
              delay={200}
            />
            <FeatureCard
              icon={Target}
              title="Mini-projets créatifs"
              description="Exercices courts et stimulants qui renforcent tes compétences de manière ludique."
              delay={300}
            />
            <FeatureCard
              icon={MessageCircle}
              title="Sessions d'accompagnement"
              description="Accompagnement personnalisé pour répondre à tes questions et débloquer tes projets."
              delay={400}
            />
            <FeatureCard
              icon={Users}
              title="Communauté motivante"
              description="Rejoins une communauté active où l'entraide et le partage sont au cœur de l'apprentissage."
              delay={500}
            />
          </div>
        </div>
      </section>

      {/* What Students Learn Section */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center space-y-6 mb-16 animate-fade-in-up">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground">
              Ce que les étudiants apprennent
            </h2>
            <div className="w-24 h-1 bg-gradient-hero mx-auto rounded-full" />
            <p className="text-xl text-muted-foreground leading-relaxed">
              Une progression sur 3 piliers essentiels
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <ProgressPillar
              icon={Eye}
              title="Vision"
              description="Comprendre comment fonctionne vraiment la technologie. Tu développes une vision claire du monde digital."
              color="primary"
              delay={0}
            />
            <ProgressPillar
              icon={TrendingUp}
              title="Progrès"
              description="Apprendre par répétition créative. Chaque semaine, tu crées quelque chose de nouveau et vois tes compétences évoluer."
              color="secondary"
              delay={200}
            />
            <ProgressPillar
              icon={Smile}
              title="Mindset"
              description="Développer la discipline douce, la motivation durable. Tu codes par plaisir, pas par obligation."
              color="accent"
              delay={400}
            />
          </div>
        </div>
      </section>

      {/* Why Different Section */}
      <section className="py-24 bg-gradient-vibrant relative overflow-hidden">
        <div className="absolute inset-0 bg-background/95" />
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-6 mb-16 animate-fade-in-up">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground">
              Pourquoi VibeCoding est différent
            </h2>
            <div className="w-24 h-1 bg-gradient-hero mx-auto rounded-full" />
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            <DifferenceCard
              icon={Sparkles}
              title="Approche par la vibe"
              description="On apprend comme on respire, naturellement. L'apprentissage devient une expérience fluide et agréable."
              delay={0}
            />
            <DifferenceCard
              icon={Zap}
              title="Méthode 100% pratique"
              description="On code avant de théoriser. Tu touches le code dès la première minute, pas après 3 mois de cours."
              delay={100}
            />
            <DifferenceCard
              icon={Clock}
              title="Rythme humain"
              description="Pas de pression, pas de comparaison. Chacun avance à son rythme, dans un environnement bienveillant."
              delay={200}
            />
            <DifferenceCard
              icon={Heart}
              title="Communauté chaleureuse"
              description="Entraide, soutien, motivation. Une communauté où chacun célèbre les victoires des autres."
              delay={300}
            />
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto">
            <div className="text-center space-y-6 mb-12 animate-fade-in-up">
              <h2 className="text-4xl md:text-5xl font-bold text-foreground">
                Questions fréquentes
              </h2>
              <div className="w-24 h-1 bg-gradient-hero mx-auto rounded-full" />
            </div>

            <Accordion type="single" collapsible className="space-y-4">
              <AccordionItem value="item-1" className="border border-border/50 rounded-xl px-6 bg-card shadow-card">
                <AccordionTrigger className="text-lg font-semibold hover:text-primary">
                  Dois-je avoir des connaissances en programmation ?
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed">
                  Pas du tout ! VibeCoding est conçu pour les débutants complets. On part de zéro et on construit 
                  ensemble, étape par étape.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-2" className="border border-border/50 rounded-xl px-6 bg-card shadow-card">
                <AccordionTrigger className="text-lg font-semibold hover:text-primary">
                  Combien de temps dure la formation ?
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed">
                  La formation s'adapte à ton rythme. En moyenne, avec 2-3h par semaine, tu verras des résultats 
                  concrets en quelques mois. Mais tu peux aller plus vite ou plus lentement selon tes disponibilités.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-3" className="border border-border/50 rounded-xl px-6 bg-card shadow-card">
                <AccordionTrigger className="text-lg font-semibold hover:text-primary">
                  Quel matériel ai-je besoin ?
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed">
                  Juste un ordinateur (PC, Mac ou Linux) et une connexion internet. On utilise des outils gratuits 
                  et tu n'as rien à acheter.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-4" className="border border-border/50 rounded-xl px-6 bg-card shadow-card">
                <AccordionTrigger className="text-lg font-semibold hover:text-primary">
                  Y a-t-il un accompagnement personnalisé ?
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed">
                  Oui ! Tu as accès à des sessions d'accompagnement régulières et à une communauté active pour 
                  poser toutes tes questions.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-5" className="border border-border/50 rounded-xl px-6 bg-card shadow-card">
                <AccordionTrigger className="text-lg font-semibold hover:text-primary">
                  Que puis-je créer après la formation ?
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed">
                  Tu pourras créer des sites web, des applications, des automations, et bien plus. Tu auras les 
                  compétences pour donner vie à tes idées et continuer à apprendre de manière autonome.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-gradient-subtle border-t border-border/50">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row justify-between items-center gap-8">
              <div className="text-center md:text-left">
                <h3 className="text-2xl font-bold bg-gradient-vibrant bg-clip-text text-transparent mb-2">
                  VibeCoding
                </h3>
                <p className="text-muted-foreground">La technologie qui se ressent</p>
              </div>

              <div className="flex gap-8">
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  Contact
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  Instagram
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  Discord
                </a>
              </div>
            </div>

            <div className="mt-8 pt-8 border-t border-border/30 text-center text-sm text-muted-foreground">
              <p>© 2024 VibeCoding. Tous droits réservés.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
