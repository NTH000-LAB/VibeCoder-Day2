import { LucideIcon } from "lucide-react";
import { Card } from "@/components/ui/card";

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  delay?: number;
}

export const FeatureCard = ({ icon: Icon, title, description, delay = 0 }: FeatureCardProps) => {
  return (
    <Card 
      className="group p-6 bg-gradient-card shadow-card hover:shadow-soft transition-all duration-300 hover:-translate-y-1 border-border/50"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="mb-4 inline-flex p-3 rounded-xl bg-gradient-hero">
        <Icon className="w-6 h-6 text-primary-foreground" />
      </div>
      <h3 className="text-xl font-bold mb-2 text-foreground group-hover:text-primary transition-colors">
        {title}
      </h3>
      <p className="text-muted-foreground leading-relaxed">
        {description}
      </p>
    </Card>
  );
};
