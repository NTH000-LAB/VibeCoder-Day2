import { LucideIcon } from "lucide-react";

interface DifferenceCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  delay?: number;
}

export const DifferenceCard = ({ icon: Icon, title, description, delay = 0 }: DifferenceCardProps) => {
  return (
    <div 
      className="relative group animate-fade-in-up"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="absolute inset-0 bg-gradient-vibrant rounded-2xl opacity-0 group-hover:opacity-10 transition-opacity duration-300" />
      <div className="relative p-8 bg-card rounded-2xl border border-border/50 shadow-card hover:shadow-soft transition-all duration-300">
        <div className="mb-4 inline-flex p-4 rounded-xl bg-gradient-subtle">
          <Icon className="w-8 h-8 text-primary" />
        </div>
        <h3 className="text-xl font-bold mb-3 text-foreground">{title}</h3>
        <p className="text-muted-foreground leading-relaxed">{description}</p>
      </div>
    </div>
  );
};
