import { LucideIcon } from "lucide-react";

interface ProgressPillarProps {
  icon: LucideIcon;
  title: string;
  description: string;
  color: "primary" | "secondary" | "accent";
  delay?: number;
}

export const ProgressPillar = ({ icon: Icon, title, description, color, delay = 0 }: ProgressPillarProps) => {
  const colorClasses = {
    primary: "from-primary to-primary-glow text-primary-foreground",
    secondary: "from-secondary to-secondary/80 text-secondary-foreground",
    accent: "from-accent to-accent/80 text-accent-foreground",
  };

  return (
    <div 
      className="relative animate-fade-in-up"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className={`p-8 rounded-2xl bg-gradient-to-br ${colorClasses[color]} shadow-soft`}>
        <Icon className="w-12 h-12 mb-4" />
        <h3 className="text-2xl font-bold mb-3">{title}</h3>
        <p className="opacity-95 leading-relaxed">{description}</p>
      </div>
    </div>
  );
};
